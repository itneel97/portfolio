import React, { Component } from 'react';
import classes from './Header.module.css';
import Aux from '../../hoc/Auxiliary/Auxiliary'
import '../../App.module.css';
// import SideDrawer from './SideDrawer/SideDrawer';

class Header extends Component {
     state = {
        navOpen: false,
    }
    constructor() {
        super();
        this.state = { navOpen: false };
        this.toggleHandler = this.toggleHandler.bind(this);
    }
   

    toggleHandler = () => {
        this.setState((prevState) => {
            return { navOpen: !prevState.navOpen };
        });
        console.log(this.state.navOpen);
    }

    render() {
        let attachedClasses = [classes.navToggle]

        if (this.state.navOpen) {
            attachedClasses= [classes.navopen]

        }

        return (

            <Aux>
                <div className={classes.body} >
                    <div className={classes.header}>
                        <div className={classes.logo}>
                            <div className={classes.devneel}>devneel</div>
                        </div>
                        <button className={attachedClasses.join(' ')} onClick={this.toggleHandler.bind(this)} >
                            <span className={classes.hamburger}></span>
                        </button>
                        <nav className={classes.nav}>
                            <ul className={classes.nav__list}>
                                <li className={classes.nav__item}><a href="#None" className={classes.nav__link}>Home</a></li>
                                <li className={classes.nav__item}><a href="#services" className={classes.nav__link}>My service</a></li>
                                <li className={classes.nav__item}><a href="#about" className={classes.nav__link}>About me</a></li>
                                <li className={classes.nav__item}><a href="#work" className={classes.nav__link}>My Work</a></li>
                            </ul>
                        </nav>

                    </div>
                </div>

            </Aux>

        );
    }

}

export default Header;